# Silvio Aguilar - 21/03/2026

# Módulo de procesamiento de ventas y devoluciones

# Constantes de negocio
DESCUENTO_VENTA_ALTA = 0.10
UMBRAL_VENTA_ALTA = 1000
UMBRAL_VIP = 500


def procesar_transacciones(transacciones):
    """
    Procesa una lista de transacciones de ventas y devoluciones.
    
    Args:
        transacciones (list): Lista de diccionarios con datos de transacciones.
    
    Returns:
        list: Resultados formateados de cada transacción procesada.
    """
    resultados = []
    
    for transaccion in transacciones:
        if es_venta_valida(transaccion):
            resultado_venta = procesar_venta(transaccion)
            resultados.append(resultado_venta)
            registrar_auditoria(transaccion['nombre'])
            
        elif es_devolucion_valida(transaccion):
            resultado_devolucion = procesar_devolucion(transaccion)
            resultados.append(resultado_devolucion)
            registrar_auditoria(transaccion['nombre'])
    
    return resultados


def es_venta_valida(transaccion):
    """Verifica que la transacción sea una venta completada con monto positivo."""
    return (transaccion['tipo'] == 'venta' and 
            transaccion['monto'] > 0 and 
            transaccion['estado'] == 'completado')


def es_devolucion_valida(transaccion):
    """Verifica que la transacción sea una devolución con monto positivo."""
    return transaccion['tipo'] == 'devolucion' and transaccion['monto'] > 0


def procesar_venta(transaccion):
    """Procesa una venta aplicando descuentos si corresponde."""
    monto_final = calcular_monto_con_descuento(transaccion)
    return formatear_resultado_venta(transaccion['nombre'], monto_final)


def procesar_devolucion(transaccion):
    """Procesa una devolución."""
    monto_devolucion = transaccion['monto'] * -1
    return formatear_resultado_devolucion(transaccion['nombre'], monto_devolucion)


def calcular_monto_con_descuento(transaccion):
    """
    Calcula el monto final aplicando 10% de descuento si:
    - El monto supera 1000, O
    - Es cliente VIP y el monto supera 500
    """
    monto_original = transaccion['monto']
    
    if aplica_descuento(transaccion):
        return monto_original * (1 - DESCUENTO_VENTA_ALTA)
    
    return monto_original


def aplica_descuento(transaccion):
    """Determina si la transacción califica para descuento."""
    es_venta_alta = transaccion['monto'] > UMBRAL_VENTA_ALTA
    es_vip_con_compra_minima = (transaccion['cliente_tipo'] == 'VIP' and 
                                 transaccion['monto'] > UMBRAL_VIP)
    
    return es_venta_alta or es_vip_con_compra_minima


def formatear_resultado_venta(nombre_cliente, monto_final):
    """Formatea el resultado de una venta."""
    return f"Cliente: {nombre_cliente} - Total: {monto_final}"


def formatear_resultado_devolucion(nombre_cliente, monto_devolucion):
    """Formatea el resultado de una devolución."""
    return f"Cliente: {nombre_cliente} - Retorno: {monto_devolucion}"


def registrar_auditoria(nombre_cliente):
    """Registra en el log el procesamiento de la transacción."""
    print(f"Procesando registro de: {nombre_cliente}")


# Datos de prueba para verificar que funciona
if __name__ == "__main__":
    datos_prueba = [
        {'tipo': 'venta', 'monto': 1200, 'estado': 'completado', 
         'cliente_tipo': 'estándar', 'nombre': 'Juan'},
        {'tipo': 'venta', 'monto': 600, 'estado': 'completado', 
         'cliente_tipo': 'VIP', 'nombre': 'Ana'},
        {'tipo': 'devolucion', 'monto': 50, 'estado': 'completado', 
         'cliente_tipo': 'estándar', 'nombre': 'Pedro'}
    ]
    
    print(procesar_transacciones(datos_prueba))